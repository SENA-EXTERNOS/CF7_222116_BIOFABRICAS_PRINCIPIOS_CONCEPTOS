function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Mfiac7gg0A":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

